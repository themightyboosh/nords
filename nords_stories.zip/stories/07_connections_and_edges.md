# [EPIC] 6: Connections, Lines & Edge Rendering

**Objective:** Implement all connection mechanics: draw-to-connect, edge rendering with Euclidean math, arrows, labels, ribboning, line hops, and the spatial-data paradigm.
**Invariant:** No pathfinding. Euclidean purity. Distance 0.0–1.0 is the data. Per-line-type normalization bound to 2500px at 100% zoom.
**Tech:** React Flow custom edges, SVG path math, Quadratic Béziers
**Ref:** `04_ui.md` §1.3, §1.6, `02_data_model.md` §1.5, `09_edge_rendering_study.md`

---

## [FEATURE] 6.1: Edge Math Engine

### [STORY] 6.1.1: Rectangle-Border Intersection Calculator
* **Target:** `src/utils/edgeMath.ts`
* **Directive:** Given two rectangles (node bounding boxes), calculate the exact point where a center-to-center line intersects each rectangle's border. Returns `{sourcePoint: {x,y}, targetPoint: {x,y}}`.
* **Ref:** `09_edge_rendering_study.md` (anchor algorithms)
* **AC:** Unit test: two 200x100 nodes at (0,0) and (400,300) → intersection points on correct edges. 8 directional test cases all pass.

### [STORY] 6.1.2: Custom Euclidean Edge Component
* **Target:** `src/components/Canvas/EuclideanEdge.tsx`
* **Directive:** Custom React Flow edge type registered as `euclidean`. Uses `edgeMath.ts` to compute border intersection points. Renders straight SVG `<path>` from source intersection to target intersection. Stroke color from connection type accent. Stroke width 2px.
* **Ref:** `05_spatial.md` §1 (Pure Edge Rendering)
* **AC:** Edges render as straight lines between node borders (not centers). Moving nodes updates edge endpoints in real-time.

### [STORY] 6.1.3: Quadratic Bézier Ribboning for Parallel Edges
* **Target:** `EuclideanEdge.tsx`, `edgeMath.ts`
* **Directive:** When 2+ connections exist between the same pair of nords, apply perpendicular offset to create "ribbon" effect using Quadratic Bézier curves. Offset = `connection_index * 12px` perpendicular to the center-to-center line. Single connections remain straight.
* **Ref:** `04_ui.md` §1.6 (Ribboning), `09_edge_rendering_study.md`
* **AC:** Two connections between Node A and Node B render as two curved lines spread apart. Three connections show three parallel curves.

---

## [FEATURE] 6.2: Edge Visual Features

### [STORY] 6.2.1: Arrow Directionality Rendering
* **Target:** `EuclideanEdge.tsx`
* **Directive:** If `direction === 'forward'`: arrowhead SVG marker at target end. If `direction === 'reverse'`: arrowhead at source end. If `direction === 'none'`: no arrowheads. Arrow uses `<marker>` SVG element filled with connection type color.
* **Ref:** `04_ui.md` §1.6, `02_data_model.md` §1.3
* **AC:** Forward connection shows arrow pointing at target. Reverse shows arrow at source. None shows plain line.

### [STORY] 6.2.2: Edge Label Positioning (Angle-Matched Pills)
* **Target:** `src/components/Canvas/EdgeLabel.tsx`
* **Directive:** Label text (connection type name or stage label) anchored at edge midpoint inside a colored pill. **Label angle matches parent line angle** via CSS `rotate()`. Auto-correct angles beyond ±90° to remain readable. When multiple ribboned edges share same nords, labels stagger along axis to avoid overlap. Labels are zoom-independent (inverse-scaled).
* **Ref:** `04_ui.md` §1.6
* **AC:** Label "Blocks" renders at 30° angle matching its edge. At 150° angle, text flips to remain readable. Zooming in/out keeps label at fixed readable size.

### [STORY] 6.2.3: Line Hops (Intersection Bridges)
* **Target:** `src/utils/lineIntersection.ts`, `EuclideanEdge.tsx`
* **Directive:** Detect where two edges cross. At intersection points, the "background" edge renders a semicircular hop (arc detour) of 8px radius, creating visual separation. Determine foreground/background by connection type sort_order.
* **Ref:** `04_ui.md` §1.6
* **AC:** Two crossing edges: one shows a small arc hop at the intersection. No visual merging of lines.

### [STORY] 6.2.4: Ghost Connections (Non-Active Types)
* **Target:** `EuclideanEdge.tsx`
* **Directive:** Connections whose type is visible but NOT the active type in Link lens render at 8% opacity. Non-visible types don't render at all.
* **Ref:** `05_spatial.md` §1
* **AC:** With "Blocks" active: "Blocks" edges at 100% opacity, "Depends On" edges at 8%, hidden types not rendered.

---

## [FEATURE] 6.3: Drawing Connections

### [STORY] 6.3.1: Drag-to-Connect (Spatial Method)
* **Target:** `src/hooks/useConnectionDraw.ts`
* **Directive:** When a nord is selected/hovered, 4 translucent connector handles appear on edges (top/right/bottom/left, 12px circles). User clicks and drags from a handle to a target node. On drop, a micro-menu appears prompting connection type selection. After type selection, connection is created with default distance 0.5.
* **Ref:** `04_ui.md` §1.3 (Spatial Method)
* **AC:** Dragging from handle to target shows live preview line. Dropping opens type selector. Selecting type creates connection with `distance_x: 0.5`.

### [STORY] 6.3.2: Connection Type Selection Micro-Menu
* **Target:** `src/components/Canvas/ConnectionTypePicker.tsx`
* **Directive:** Small popup at drop position. Lists all connection types (icon + name + color swatch). Single-click selects. Click-outside cancels. If only one connection type exists, auto-select it.
* **AC:** With 3 connection types defined, popup shows 3 options. Selecting one creates the connection. Canceling removes the preview line.

### [STORY] 6.3.3: Line Detail Interaction (Click to Select)
* **Target:** `EuclideanEdge.tsx`
* **Directive:** Clicking an edge selects it (thickens stroke to 4px, adds glow). Right-click opens context menu: Edit (opens Detail Drawer in Line Mode), Delete, Change Direction. Double-click opens Detail Drawer directly.
* **Ref:** `04_ui.md` §1.6
* **AC:** Clicking edge selects it visually. Double-click opens Detail Drawer showing line properties.

---

## [FEATURE] 6.4: Distance = Data Engine

### [STORY] 6.4.1: Real-Time Distance Calculation on Drag
* **Target:** `src/hooks/useDistanceSync.ts`
* **Directive:** When a node is dragged in Link Lens (single active line type), calculate the Euclidean distance between it and all connected nodes for the active type. Normalize to 0.0–1.0 using `MAX_DISTANCE_PX = 2500`. Update `distance_x` in real-time. Persist on drag end.
* **Ref:** `02_data_model.md` §1.5
* **AC:** Dragging Node A toward Node B: distance decreases. At 0px apart: 0.0. At 2500px apart: 1.0. Beyond 2500px: clamps at 1.0. Value persists to database.

### [STORY] 6.4.2: Drag Distance Info Panel
* **Target:** `src/components/Canvas/DragInfoPanel.tsx`
* **Directive:** During drag in Link Lens with single active line type: floating panel near cursor shows live distance value (0.0–1.0), stage label (e.g., "Doing"), and line type name. For multi-line scenarios, show compact stack of all affected connections. Panel disappears on drag end.
* **Ref:** `04_ui.md` §1.9
* **AC:** Dragging a nord shows info panel updating at 60fps. Panel shows "Blocks: 0.45 (In Progress)".

### [STORY] 6.4.3: Bidirectional Sync — Stage Selection Updates Position
* **Target:** `useDistanceSync.ts`
* **Directive:** When stage label is changed via Detail Drawer dropdown (e.g., "To Do" → "Done"), calculate the median distance value for that stage bucket and update `distance_x`. Trigger physics engine to reposition the nord to match the new distance.
* **Ref:** `02_data_model.md` §1.4 (Bi-Directional UI Sync)
* **AC:** Changing "Blocks" stage from "To Do" (0.167) to "Done" (0.833) physically moves the connected nords apart on canvas.

### [STORY] 6.4.4: Spatial Locking (>1 Active Line Type)
* **Target:** `src/hooks/useSpatialLock.ts`
* **Directive:** When >1 line type has physics activity toggled ON, enter "Spatially Locked" state. Nodes cannot be dragged to write distance. Attempting drag shows rubber-band snap-back + lock cursor icon. Info panel does not appear.
* **Ref:** `05_spatial.md` §2.1 (Overlapping Vector Paradox)
* **AC:** With 2 active line types: dragging a node snaps it back. Lock icon appears on cursor. With 1 active type: drag works normally.
